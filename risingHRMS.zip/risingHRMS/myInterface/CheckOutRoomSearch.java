package myinterface;

/**
 * This interface represents a search for checking out a room.
 */
public interface CheckOutRoomSearch {
  void deleteRoomEntry();
}
