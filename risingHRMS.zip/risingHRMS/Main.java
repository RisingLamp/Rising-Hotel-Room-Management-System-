import myclasses.Login;

public class Main {
  public static void main(String[] args) {

    new Login();
  }
}
